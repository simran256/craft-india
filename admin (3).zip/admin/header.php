 <header class="main-header">
    <a href="index.php" class="logo">
        
      <span class="logo-lg"><b>Admin</b></span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
   
      <div class="pull-right">
		  <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
		</div>
    </nav>
  </header>